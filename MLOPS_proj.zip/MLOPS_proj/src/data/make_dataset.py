import os
import torch
from torchvision import transforms


def process_data():
    print("I am executing make_dataset.py")
    print(f"Current working directory is: {os.getcwd()}")
    raw_path = f"{os.getcwd()}/data/raw"
    processed_path = f"{os.getcwd()}/data/processed"
    
    train_data, train_labels = [ ], [ ]
    for i in range(6):
        train_data.append(torch.load(f"{raw_path}/train_images_{i}.pt"))
        train_labels.append(torch.load(f"{raw_path}/train_target_{i}.pt"))

    # Step 2: Concatenate tensors into a single tensor
    train_data = torch.cat(train_data, dim=0)  # Concatenate train_data tensors
    train_labels = torch.cat(train_labels, dim=0)  # Concatenate train_labels tensors
    
    test_data = torch.load(f"{os.getcwd()}/data/raw/test_images.pt")
    test_labels = torch.load(f"{os.getcwd()}/data/raw/test_target.pt")

    print(train_data.shape)  # Check the shape of the concatenated tensor
    print(train_labels.shape)  # Check the shape of the concatenated labels tensor
    print(test_data.shape)
    print(test_labels.shape)

    train_data = train_data.unsqueeze(1)
    test_data = test_data.unsqueeze(1)

    # Step 3: Normalization
    # Calculate mean and std
    mean = train_data.mean()
    std = train_data.std()
    normalize_transform = transforms.Normalize(mean=[mean], std=[std])

    train_data = normalize_transform(train_data)
    test_data = normalize_transform(test_data)

    # Step 4: Save processed data
    # Salvataggio della rappresentazione intermedia normalizzata nella cartella data/processed
    os.makedirs(processed_path, exist_ok=True)
    torch.save(train_data, os.path.join(processed_path, 'normalized_train_data.pt'))
    torch.save(test_data, os.path.join(processed_path, 'normalized_test_data.pt'))

    return (
        torch.utils.data.TensorDataset(train_data, train_labels),
        torch.utils.data.TensorDataset(test_data, test_labels)
    )
    
if __name__ == "__main__":
    process_data()