from MLOPS_proj.models.model import MyNeuralNet
from MLOPS_proj.predict_model import predict