import torch
from torch import nn
import matplotlib.pyplot as plt
from models.model import mymodel
import os

from data.make_dataset import process_data
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def train(lr, batch_size, num_epochs):
    """Train a model on MNIST."""
    print("Training day and night")
    print(lr)
    print(batch_size)
    
    models_path = f"{os.getcwd()}/src/models/trained"
    figures_path = f"{os.getcwd()}/reports/figures"

    # Ensure the figures directory exists, create it if not
    os.makedirs(figures_path, exist_ok=True)

    # TODO: Implement training loop here
    model = mymodel.to(device)
    train_set, _ = process_data()
    train_dataloader = torch.utils.data.DataLoader(train_set, batch_size=batch_size)

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()

    losses = []  # Store losses for plotting the training curve

    for epoch in range(num_epochs):
        epoch_losses = []  # Store losses for each epoch

        for batch in train_dataloader:
            optimizer.zero_grad()
            x, y = batch
            x = x.to(device)
            y = y.to(device)
            y_pred = model(x)
            loss = loss_fn(y_pred, y)
            loss.backward()
            optimizer.step()

            epoch_losses.append(loss.item())  # Append loss for each batch

        epoch_loss = sum(epoch_losses) / len(epoch_losses)  # Calculate epoch loss
        losses.append(epoch_loss)  # Append epoch loss

        print(f"Epoch {epoch} Loss {epoch_loss}")

    # Plotting the training curve
    plt.figure(figsize=(8, 6))
    plt.plot(losses, label='Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Curve')
    plt.legend()
    
    # Save the plot as a PNG file in the figures directory
    plt.savefig(os.path.join(figures_path, "training_curve.png"))
    plt.close()  # Close the plot to free up memory

    # Save the trained model
    torch.save(model.state_dict(), os.path.join(models_path, "model.pt"))
    
if __name__ == "__main__":
    lr = 1e-3
    batch_size = 256
    num_epochs = 5
    train(lr, batch_size, num_epochs)
